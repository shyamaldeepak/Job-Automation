# AI Job Search Automation — Implementation Guide

A complete, production-minded build for a system that collects jobs daily, scores them with AI against your profile, stores the qualified ones, emails you a digest, and feeds a dashboard. Built on n8n + OpenAI (gpt-4o-mini) + Google Sheets/Gmail, with an optional PostgreSQL path.

This guide ships with four other files:

| File | What it is |
|---|---|
| `AI_Job_Search_Automation.json` | The importable n8n workflow (20 nodes) |
| `schema.sql` | PostgreSQL schema + dashboard views (optional storage) |
| `candidate_profile_template.csv` | Headers + sample row for the profile sheet |
| `jobs_output_headers.csv` | Header row for the output sheet |
| `dashboard.html` | Standalone live dashboard reading a published sheet |

---

## 0. A note on job sources (read this first)

The original template implied scraping LinkedIn, Indeed, Glassdoor, etc. Those sites actively block automated access and their terms of service prohibit scraping. For a job that runs unattended every morning, that path is fragile (it breaks the moment they change markup or roll an anti-bot challenge) and legally risky. This build instead uses **official, API-first sources** that are stable and permitted:

| Source | Auth | Cost | Coverage |
|---|---|---|---|
| **RemoteOK** | none | free | Remote tech roles |
| **Arbeitnow** | none | free | EU + remote, ATS-sourced, visa-sponsor flag |
| **Remotive** | none | free | Curated remote roles |
| **Adzuna** | free app_id/app_key | free tier | Aggregates many boards across 12+ countries (this is your Indeed-style breadth) |

If you specifically need LinkedIn/Indeed/Glassdoor listings, do it through a **licensed aggregator** (e.g. SerpApi's Google Jobs engine, Bright Data, or the Apify job-board actors) rather than scraping them yourself — those services hold the data agreements. The workflow is built so adding a source is just one more HTTP node plus a branch in the `Normalize Jobs` node. Everything downstream is source-agnostic.

---

## 1. Architecture & data flow

```
Daily 8 AM trigger
   → Load candidate profile (Google Sheets)
   → Build search queries (Code)
   → Fetch jobs in parallel: RemoteOK · Arbeitnow · Remotive · Adzuna (HTTP ×4)
   → Merge sources
   → Normalize to one schema + compute job_key (Code)
   → Dedupe within run + rule-based pre-filter (Code)   ← cuts AI cost
   → Prepare AI prompt (Code)
   → OpenAI score each job, gpt-4o-mini, JSON output (HTTP)
   → Parse AI result (Code)
   → IF fit_score ≥ 50
        → Save to Google Sheets (appendOrUpdate on job_key)  ← cross-run dedupe
        → [optional] Save to Postgres
        → Build email body (Code) → Send daily email (Gmail)

Separate error chain: Error Trigger → Email alert
```

The pipeline is idempotent: the `job_key` (an MD5 of `lower(title|company)`) is the primary key everywhere, so re-running the same day never creates duplicate rows.

---

## 2. Candidate profile storage

Create a Google Sheet named e.g. **Job Search**. Tab 1 = `Profile`. Put these headers in row 1 and your data in row 2 (see `candidate_profile_template.csv`):

`name`, `skills`, `experience`, `preferred_roles`, `preferred_countries`, `preferred_salary`, `preferred_work_type`

- `skills` / `preferred_roles` / `preferred_countries`: comma-separated.
- `preferred_countries`: the first entry drives the Adzuna country code (the workflow maps common names → codes; defaults to `gb`).
- `preferred_work_type`: `Remote` / `Hybrid` / `On-site`.

Tab 2 = `Jobs` (the output). Paste the header row from `jobs_output_headers.csv` into row 1. The workflow fills the rest automatically.

---

## 3. Node-by-node configuration

Open the workflow after importing (Section 8). Each node below lists what you must change. Anything shown as `YOUR_…` is a placeholder.

**1. Daily 8AM Trigger** — Schedule Trigger, cron `0 8 * * *`. Change the hour or add a timezone under workflow settings if needed.

**2. Load Candidate Profile** — Google Sheets, *Get rows*. Set `documentId` → your sheet ID, `sheetName` → `Profile`. Pick your Google Sheets OAuth credential.

**3. Build Search Queries** — Code. No edits required; it derives query terms and the Adzuna country code from the profile. Tune the `countryMap` if you target countries not listed.

**4. Fetch RemoteOK** — HTTP GET `https://remoteok.com/api`. Keep the `User-Agent` header (RemoteOK rejects blank agents). Retry on fail is on.

**5. Fetch Arbeitnow** — HTTP GET `https://www.arbeitnow.com/api/job-board-api`. Add `?visa_sponsorship=true` to the URL if that matters to you.

**6. Fetch Remotive** — HTTP GET `https://remotive.com/api/remote-jobs?search=…`. The `search` term is bound to your primary role.

**7. Fetch Adzuna** — HTTP GET `https://api.adzuna.com/v1/api/jobs/{country}/search/1`. Replace `YOUR_ADZUNA_APP_ID` and `YOUR_ADZUNA_APP_KEY` in the query parameters. `results_per_page` is 50.

**8. Merge Sources** — Merge, mode *Append*, 4 inputs. No edits.

**9. Normalize Jobs** — Code. Maps each source's shape into the canonical job schema and computes `job_key`. Edit only if you add a new source.

**10. Dedupe + Pre-filter** — Code. Drops in-run duplicates and rejects jobs that (a) fall outside the target domains, (b) look senior / >3 yrs, or (c) require fluency in an unlisted local language — *before* you pay OpenAI. Tune the `KEEP`, `SENIOR`, `LOCAL_LANG` regexes to taste.

**11. Prepare AI Prompt** — Code. Renders the scoring prompt per job and carries the original job on `__job`. No edits.

**12. OpenAI Score Job** — HTTP POST `https://api.openai.com/v1/chat/completions`, model `gpt-4o-mini`, `response_format: json_object`, temperature 0.2. Auth = generic **Header Auth** credential: header `Authorization`, value `Bearer YOUR_OPENAI_KEY`. Retry ×3.

**13. Parse AI Result** — Code. Parses the JSON (with a regex fallback) and merges scores onto the job. No edits.

**14. Fit Score ≥ 50** — IF node. Change `50` to your threshold (see §4).

**15. Save to Google Sheets** — Google Sheets, *Append or update*, match column `job_key`. Set `documentId` → your sheet ID, `sheetName` → `Jobs`. Using *append-or-update* on `job_key` is what prevents cross-run duplicates.

**16. Save to Postgres (optional)** — disabled by default. Enable, set the Postgres credential, point at the `jobs` table (`skipOnConflict` on). See §5.

**17. Build Email Body** — Code. Collapses qualified jobs into one HTML email, top 20 by fit. Edit styling/copy here.

**18. Send Daily Email** — Gmail. Set `sendTo` to your address; pick your Gmail OAuth credential.

**19. On Workflow Error** + **20. Email Error Alert** — independent Error Trigger chain that emails you the failing node + message. Set this workflow as its own *Error Workflow* in Settings so any failure notifies you.

---

## 4. The AI scoring prompt

The system message frames the model as a strict technical recruiter that must return JSON only. The per-job user message injects the profile and the (truncated) job description and asks for:

- five sub-scores 0–100: `skill_match`, `experience_match`, `location_match`, `salary_match`, `growth_potential`
- a weighted `fit_score` (skill 35%, experience 20%, location 15%, salary 15%, growth 15%)
- `recommendation` (`strong apply` / `apply` / `maybe` / `skip`)
- `matching_skills`, `missing_skills` (arrays), and a 2-sentence `summary`

Two hard guards live in the prompt: cap `fit_score` at 35 when a role needs >3 years, and at 30 when it needs fluency in a local language the candidate didn't list. This mirrors the rule-based pre-filter so borderline cases that slipped through still get penalised.

**Threshold guidance:** 60 = strict / high-signal only · 50 = balanced (default) · 40 = higher volume. `response_format: json_object` plus `temperature: 0.2` keeps output parseable and stable. Because the system prompt is a stable prefix, OpenAI prompt caching will further cut input cost on busy days.

---

## 5. Storage

**Google Sheets (default):** the `Jobs` tab is the system of record. *Append-or-update on `job_key`* gives you free idempotency and a sheet you can sort/filter by hand.

**PostgreSQL (optional, for scale/analytics):** run `schema.sql`. It creates `candidate_profile`, `jobs` (PK `job_key`), a `run_log` table, and three dashboard views: `v_dashboard_summary`, `v_best_companies`, `v_skill_gaps`. Enable node 16, point it at the `jobs` table with `skipOnConflict` so re-runs are safe. You can run both stores in parallel.

---

## 6. Daily email report

Node 17 builds an HTML table of the top 20 qualified jobs: rank, role + company + location, fit score, missing skills, and an Apply link, with a header line showing match count and average fit. Gmail sends it. Edit the `BUILD_EMAIL_JS` template to change columns, branding, or to switch to a plain-text body.

---

## 7. Dashboard

`dashboard.html` is a standalone page — no build step, no server. It reads your **published** Google Sheet as CSV and renders: four KPI cards (total jobs, total matches, average fit, collected today), best-companies-by-fit, top skill gaps, fit-score distribution, source breakdown, and a top-20 table.

To wire it up: in Google Sheets, **File → Share → Publish to web → the `Jobs` tab → CSV**, copy that link, paste it into the dashboard's input, click **Load**. It opens on sample data so you can see the layout immediately. (If you use Postgres instead, the three SQL views give you the same metrics for any BI tool — Metabase, Grafana, Looker Studio.)

---

## 8. Deployment

**Option A — n8n Cloud (fastest):** sign up at n8n.io, **Workflows → Import from File** → `AI_Job_Search_Automation.json`. Create the four credentials (below), open each placeholder node and select them, fill the `YOUR_…` IDs/keys, then toggle the workflow **Active**. The schedule trigger fires daily.

**Option B — self-host (free):**
```bash
# Docker
docker volume create n8n_data
docker run -d --name n8n -p 5678:5678 \
  -e GENERIC_TIMEZONE="Europe/London" \
  -e TZ="Europe/London" \
  -v n8n_data:/home/node/.n8n \
  docker.n8n.io/n8nio/n8n
# open http://localhost:5678, then import the JSON as above
```
For a 24/7 unattended schedule, host it on a small always-on VM (Fly.io, Railway, a $5 VPS) rather than your laptop. Set `GENERIC_TIMEZONE` so `0 8 * * *` means 8 AM your time.

**Credentials to create in n8n:**
1. **Google Sheets OAuth2** — used by nodes 2 and 15.
2. **Gmail OAuth2** — nodes 18 and 20.
3. **Header Auth** (for OpenAI) — name it "OpenAI Bearer", header `Authorization`, value `Bearer sk-…`.
4. **Postgres** (optional) — node 16.

---

## 9. API setup

- **OpenAI:** platform.openai.com → API keys → create key. Add a small prepaid balance and set a monthly budget cap + email alert under Billing. New accounts default to GPT-4.1 endpoints; `gpt-4o-mini` still works and stays cheapest, but see the cost note for `gpt-4.1-mini` / `gpt-4.1-nano` alternatives.
- **Adzuna:** developer.adzuna.com → register → create an app → copy `app_id` + `app_key` into node 7. Free tier has daily/monthly call limits, fine for one run/day.
- **Google (Sheets + Gmail):** in Google Cloud Console create OAuth credentials and enable the Sheets and Gmail APIs, or use n8n's built-in Google OAuth flow which handles scopes for you.
- **RemoteOK / Arbeitnow / Remotive:** no keys.

---

## 10. Cost estimation

Token math per job: ~1,500 input tokens (system + profile + truncated description + instructions) and ~280 output tokens. At gpt-4o-mini rates ($0.15 / 1M input, $0.60 / 1M output):

| Jobs scored per day (after pre-filter) | Daily OpenAI cost | ~Monthly |
|---|---|---|
| 40 | ~$0.016 | **~$0.47** |
| 100 | ~$0.039 | ~$1.17 |
| 250 | ~$0.098 | ~$2.95 |

Everything else: RemoteOK / Arbeitnow / Remotive / Adzuna = free; Google Sheets + Gmail = free; n8n self-hosted = free (a tiny VPS is ~$5/mo) or n8n Cloud Starter ≈ $20–24/mo. **Realistic all-in: under ~$2/month self-hosted**, or ~$22/month if you pay for n8n Cloud. The pre-filter is the main cost lever — it discards out-of-scope jobs before any token is spent. Cheaper still: route scoring to `gpt-4.1-nano` ($0.10 / $0.40). *(Verify current model prices on OpenAI's pricing page before committing.)*

---

## 11. Error handling, logging & recovery

- **Retries:** every HTTP node retries 3× with a back-off, so a transient API blip self-heals.
- **Graceful source failure:** the source HTTP nodes use *continue on error*, so if one job board is down the others still flow through — you get a partial run, not a dead one.
- **Duplicate detection:** `job_key` + append-or-update / `skipOnConflict` make the whole pipeline idempotent across runs.
- **Failure alerts:** the Error Trigger chain emails you the failing node and message. Set the workflow as its own Error Workflow in Settings.
- **Logging:** the Code nodes `console.log` counts (visible in each execution). n8n's **Executions** list is your audit trail — turn on "Save successful/failed executions" in Settings. With Postgres, write a row to `run_log` per run for long-term observability.
- **Run history:** keep manual executions saved while tuning, then trim retention once stable.

---

## 12. Best practices & next steps

- Start with the threshold at 50 and a single primary role; widen once you trust the scores.
- Keep the description truncated (3,500 chars) — it caps cost and rarely changes the score.
- Add sources by adding one HTTP node + one branch in `Normalize Jobs`; nothing else changes.
- Put the static system prompt first (already done) to benefit from prompt caching.
- Don't over-fetch: one run/day respects every free tier comfortably.
- Review `missing_skills` trends in the dashboard — that's your personal upskilling backlog.

---

*Replace every `YOUR_…` placeholder before activating. Treat the workflow JSON as a starting point: it's structured so the parts you'll actually tune (sources, regex filters, threshold, prompt, email layout) are isolated in clearly named nodes.*
