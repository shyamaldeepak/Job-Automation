-- ============================================================================
-- AI Job Search Automation — PostgreSQL schema
-- Optional alternative (or complement) to Google Sheets storage.
-- ============================================================================

CREATE TABLE IF NOT EXISTS candidate_profile (
    id                  SERIAL PRIMARY KEY,
    name                TEXT NOT NULL,
    skills              TEXT,                       -- comma-separated
    experience          TEXT,                       -- e.g. "2 years, ML internships"
    preferred_roles     TEXT,
    preferred_countries TEXT,
    preferred_salary    TEXT,
    preferred_work_type TEXT DEFAULT 'Remote',
    updated_at          TIMESTAMPTZ DEFAULT now()
);

-- One row per unique job. job_key = md5(lower(title|company)) guarantees idempotency.
CREATE TABLE IF NOT EXISTS jobs (
    job_key            CHAR(32) PRIMARY KEY,        -- dedupe key (matches n8n Normalize node)
    title              TEXT NOT NULL,
    company            TEXT NOT NULL,
    location           TEXT,
    salary             TEXT,
    description        TEXT,
    apply_link         TEXT,
    source             TEXT,                        -- remoteok | arbeitnow | remotive | adzuna
    date_posted        DATE,

    -- AI scoring fields
    skill_match        SMALLINT,
    experience_match   SMALLINT,
    location_match     SMALLINT,
    salary_match       SMALLINT,
    growth_potential   SMALLINT,
    fit_score          SMALLINT,
    recommendation     TEXT,                        -- strong apply | apply | maybe | skip
    matching_skills    TEXT,
    missing_skills     TEXT,
    ai_summary         TEXT,

    collected_at       TIMESTAMPTZ DEFAULT now(),
    emailed            BOOLEAN DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_jobs_fit        ON jobs (fit_score DESC);
CREATE INDEX IF NOT EXISTS idx_jobs_collected  ON jobs (collected_at DESC);
CREATE INDEX IF NOT EXISTS idx_jobs_company    ON jobs (company);
CREATE INDEX IF NOT EXISTS idx_jobs_source     ON jobs (source);

-- Lightweight run log for observability / error recovery.
CREATE TABLE IF NOT EXISTS run_log (
    id             SERIAL PRIMARY KEY,
    run_at         TIMESTAMPTZ DEFAULT now(),
    jobs_fetched   INTEGER,
    jobs_scored    INTEGER,
    jobs_qualified INTEGER,
    avg_fit        NUMERIC(5,2),
    status         TEXT,                            -- success | partial | failed
    error_detail   TEXT
);

-- ----------------------------------------------------------------------------
-- Dashboard views
-- ----------------------------------------------------------------------------

-- Headline metrics
CREATE OR REPLACE VIEW v_dashboard_summary AS
SELECT
    COUNT(*)                                              AS total_jobs,
    COUNT(*) FILTER (WHERE fit_score >= 50)               AS total_matches,
    ROUND(AVG(fit_score), 1)                              AS avg_fit_score,
    COUNT(*) FILTER (WHERE collected_at >= now() - INTERVAL '1 day') AS jobs_today
FROM jobs;

-- Best companies by average fit (min 2 postings)
CREATE OR REPLACE VIEW v_best_companies AS
SELECT company,
       COUNT(*)               AS postings,
       ROUND(AVG(fit_score),1) AS avg_fit
FROM jobs
GROUP BY company
HAVING COUNT(*) >= 2
ORDER BY avg_fit DESC, postings DESC
LIMIT 15;

-- Skill-gap frequency: unnest comma-separated missing_skills and count.
CREATE OR REPLACE VIEW v_skill_gaps AS
SELECT TRIM(skill) AS missing_skill, COUNT(*) AS frequency
FROM jobs,
     LATERAL unnest(string_to_array(missing_skills, ',')) AS skill
WHERE missing_skills IS NOT NULL AND TRIM(skill) <> ''
GROUP BY TRIM(skill)
ORDER BY frequency DESC
LIMIT 20;
